import { getToken } from './api.js';

let socket = null;
let reconnectTimer = null;
const listeners = new Set();

export const connectWS = () => {
  if (socket) return;

  const token = getToken();
  if (!token) return;

  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  const wsUrl = `${protocol}//${host}/ws?token=${token}`;

  socket = new WebSocket(wsUrl);

  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      listeners.forEach(l => l(data));
    } catch (err) {
      console.error('WS parse error', err);
    }
  };

  socket.onclose = () => {
    socket = null;
    if (getToken()) {
      clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(connectWS, 3000);
    }
  };

  socket.onerror = (err) => {
    console.error('WS error', err);
    socket.close();
  };
};

export const subscribeWS = (callback) => {
  listeners.add(callback);
  return () => listeners.delete(callback);
};

export const disconnectWS = () => {
  if (socket) {
    socket.close();
    socket = null;
  }
  clearTimeout(reconnectTimer);
};
