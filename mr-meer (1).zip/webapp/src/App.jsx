import React, { useState, useEffect, useMemo } from 'react';
import { Routes, Route, Navigate, Link, useLocation, useNavigate } from 'react-router-dom';
import { api, getToken, clearToken } from './api';
import { connectWS, disconnectWS, subscribeWS } from './ws';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Sessions from './pages/Sessions.jsx';
import Commands from './pages/Commands.jsx';
import Groups from './pages/Groups.jsx';
import Logs from './pages/Logs.jsx';
import Settings from './pages/Settings.jsx';
import Sidebar from './components/Sidebar.jsx';
import Topbar from './components/Topbar.jsx';
import { ToastProvider, useToast } from './components/Toast.jsx';

const Layout = ({ children }) => {
  const location = useLocation();
  const [glitch, setGlitch] = useState(false);

  useEffect(() => {
    setGlitch(true);
    const timer = setTimeout(() => setGlitch(false), 150);
    return () => clearTimeout(timer);
  }, [location.pathname]);

  return (
    <div className="app-container">
      <Sidebar />
      <div className="topbar-wrapper">
        <Topbar title={getPageTitle(location.pathname)} />
      </div>
      <main className={`main-content ${glitch ? 'glitch-effect' : ''}`}>
        {children}
      </main>
    </div>
  );
};

const getPageTitle = (path) => {
  const titles = {
    '/': 'DASHBOARD',
    '/sessions': 'SESSIONS',
    '/commands': 'COMMANDS',
    '/groups': 'GROUPS',
    '/logs': 'LOGS',
    '/settings': 'SETTINGS',
  };
  return titles[path] || 'MEER HACKING HUB';
};

const ProtectedRoute = ({ children }) => {
  const token = getToken();
  if (!token) return <Navigate to="/login" replace />;
  return <Layout>{children}</Layout>;
};

function App() {
  useEffect(() => {
    const token = getToken();
    if (token) {
      connectWS();
    }
    return () => disconnectWS();
  }, []);

  return (
    <ToastProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/sessions" element={<ProtectedRoute><Sessions /></ProtectedRoute>} />
        <Route path="/commands" element={<ProtectedRoute><Commands /></ProtectedRoute>} />
        <Route path="/groups" element={<ProtectedRoute><Groups /></ProtectedRoute>} />
        <Route path="/logs" element={<ProtectedRoute><Logs /></ProtectedRoute>} />
        <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </ToastProvider>
  );
}

export default App;
