const API_URL = import.meta.env.VITE_API_URL || '';

export const getToken = () => localStorage.getItem('token');
export const setToken = (token) => localStorage.setItem('token', token);
export const clearToken = () => localStorage.removeItem('token');

async function request(endpoint, method = 'GET', body = null) {
  const headers = {
    'Content-Type': 'application/json',
  };
  const token = getToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_URL}/api${endpoint}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Request failed');
  }

  return response.json();
}

export const api = {
  login: (username, password) => request('/auth/login', 'POST', { username, password }),
  changePassword: (oldPassword, newPassword) => request('/auth/change-password', 'POST', { oldPassword, newPassword }),
  me: () => request('/auth/me'),
  
  sessions: () => request('/sessions'),
  createSession: (phone) => request('/sessions', 'POST', { phone }),
  deleteSession: (id) => request(`/sessions/${id}`, 'DELETE'),
  getQr: (id) => request(`/sessions/${id}/qr`),
  pairSession: (id, phone) => request(`/sessions/${id}/pair`, 'POST', { phone }),
  
  listCommands: () => request('/commands/list'),
  runCommand: (name, args) => request('/commands/run', 'POST', { name, args }),
  
  logs: (limit, sessionId) => request(`/logs?limit=${limit}${sessionId ? `&session=${sessionId}` : ''}`),
  commandHistory: (limit) => request(`/logs/commands?limit=${limit}`),
  
  getSettings: () => request('/settings'),
  updateSettings: (data) => request('/settings', 'POST', data),
};
