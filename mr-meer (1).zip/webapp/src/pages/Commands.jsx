import React, { useState, useEffect } from 'react';
import { api } from '../api.js';
import { useToast } from '../components/Toast.jsx';

const Commands = () => {
  const [sessions, setSessions] = useState([]);
  const [selectedSession, setSelectedSession] = useState('');
  const [commands, setCommands] = useState([]);
  const [selectedCommand, setSelectedCommand] = useState(null);
  const [args, setArgs] = useState({});
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const toast = useToast();

  useEffect(() => {
    Promise.all([
      api.sessions(),
      api.listCommands(),
      api.commandHistory(20)
    ]).then(([s, c, h]) => {
      setSessions(s.filter(x => x.status === 'connected'));
      setCommands(c);
      setHistory(h);
    });
  }, []);

  const handleCommandSelect = (cmd) => {
    setSelectedCommand(cmd);
    setArgs({});
    setResult(null);
  };

  const handleRun = async () => {
    if (!selectedSession) return toast.error('SELECT A SESSION FIRST');
    setLoading(true);
    setResult(null);
    try {
      const res = await api.runCommand(selectedCommand, { ...args, id: selectedSession });
      setResult(res.result);
      toast.success('COMMAND EXECUTED');
      // Refresh history
      api.commandHistory(20).then(setHistory);
    } catch (err) {
      toast.error(err.message);
      setResult({ error: err.message });
    }
    setLoading(false);
  };

  const renderField = (name, type = 'text', placeholder = '', options = null) => {
    if (type === 'textarea') {
      return (
        <div key={name} style={{ marginBottom: '15px' }}>
          <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>{name.toUpperCase()}</label>
          <textarea 
            placeholder={placeholder} 
            value={args[name] || ''} 
            onChange={e => setArgs({ ...args, [name]: e.target.value })}
            rows={4}
          />
        </div>
      );
    }
    return (
      <div key={name} style={{ marginBottom: '15px' }}>
        <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>{name.toUpperCase()}</label>
        <input 
          type={type}
          placeholder={placeholder} 
          value={args[name] || ''} 
          onChange={e => setArgs({ ...args, [name]: type === 'number' ? parseInt(e.target.value) : e.target.value })}
        />
      </div>
    );
  };

  const renderForm = () => {
    if (!selectedCommand) return <div style={{ color: 'var(--muted)', textAlign: 'center', padding: '100px' }}>SELECT A COMMAND TO BEGIN</div>;

    const fields = {
      'msg.send': [renderField('to', 'text', 'JID or number'), renderField('text', 'textarea', 'Message content')],
      'msg.bulk': [renderField('targets', 'textarea', 'One per line or comma'), renderField('text', 'textarea'), renderField('delayMs', 'number', 'Default 1500')],
      'group.create': [renderField('name'), renderField('members', 'textarea', 'One per line')],
      'group.add': [renderField('group', 'text', 'Group JID'), renderField('numbers', 'textarea')],
      'group.remove': [renderField('group', 'text', 'Group JID'), renderField('numbers', 'textarea')],
      'group.promote': [renderField('group', 'text', 'Group JID'), renderField('numbers', 'textarea')],
      'group.demote': [renderField('group', 'text', 'Group JID'), renderField('numbers', 'textarea')],
      'group.leave': [renderField('group')],
      'group.subject': [renderField('group'), renderField('subject')],
      'group.desc': [renderField('group'), renderField('desc', 'textarea')],
      'user.check': [renderField('number')],
      'user.block': [renderField('target')],
      'user.unblock': [renderField('target')],
      'user.pfp': [renderField('target')],
      'attack.flood': [renderField('target'), renderField('count', 'number'), renderField('text', 'textarea'), renderField('delayMs', 'number')],
      'attack.random': [renderField('target'), renderField('count', 'number'), renderField('texts', 'textarea', 'One per line'), renderField('minMs', 'number'), renderField('maxMs', 'number')],
      'session.pair': [renderField('phone')],
    };

    return (
      <div className="panel" style={{ animation: 'glitch 0.2s' }}>
        <h3 style={{ color: 'var(--accent)', marginTop: 0 }}>{selectedCommand.toUpperCase()}</h3>
        {fields[selectedCommand] || <p style={{ color: 'var(--muted)' }}>No arguments required for this command.</p>}
        <button className="btn-primary" onClick={handleRun} disabled={loading} style={{ width: '100%', marginTop: '20px' }}>
          {loading ? 'EXECUTING...' : 'RUN COMMAND'}
        </button>
      </div>
    );
  };

  const groups = {
    'Session': ['session.pair', 'session.logout'],
    'Messaging': ['msg.send', 'msg.bulk'],
    'Groups': ['group.create', 'group.add', 'group.remove', 'group.promote', 'group.demote', 'group.leave', 'group.subject', 'group.desc', 'group.list'],
    'User Ops': ['user.check', 'user.block', 'user.unblock', 'user.pfp'],
    'Attack': ['attack.flood', 'attack.random']
  };

  return (
    <div>
      <div className="panel" style={{ marginBottom: '30px', display: 'flex', alignItems: 'center', gap: '20px' }}>
        <div style={{ flex: 1 }}>
          <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>SELECT ACTIVE SESSION</label>
          <select value={selectedSession} onChange={e => setSelectedSession(e.target.value)}>
            <option value="">-- SELECT SESSION --</option>
            {sessions.map(s => <option key={s.id} value={s.id}>{s.name || s.id} ({s.phone})</option>)}
          </select>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', gap: '30px' }}>
        <div className="panel" style={{ height: 'calc(100vh - 250px)', overflowY: 'auto' }}>
          {Object.entries(groups).map(([name, cmds]) => (
            <div key={name} style={{ marginBottom: '20px' }}>
              <div style={{ fontSize: '0.7rem', color: 'var(--muted)', padding: '5px 10px' }}>{name.toUpperCase()}</div>
              {cmds.map(cmd => (
                <div 
                  key={cmd} 
                  onClick={() => handleCommandSelect(cmd)}
                  style={{ 
                    padding: '8px 10px', 
                    cursor: 'pointer', 
                    fontSize: '0.85rem',
                    color: selectedCommand === cmd ? 'var(--accent)' : 'var(--text)',
                    background: selectedCommand === cmd ? 'rgba(0, 255, 136, 0.1)' : 'transparent',
                    borderLeft: selectedCommand === cmd ? '2px solid var(--accent)' : 'none'
                  }}
                >
                  {cmd.split('.')[1].toUpperCase()}
                </div>
              ))}
            </div>
          ))}
        </div>

        <div>
          {renderForm()}
          
          {result && (
            <div className="panel" style={{ marginTop: '20px', background: '#050505', color: 'var(--accent-2)' }}>
              <h4 style={{ marginTop: 0, fontSize: '0.8rem' }}>RESULT DATA</h4>
              <pre style={{ fontSize: '0.75rem', overflow: 'auto' }}>{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}

          <div className="panel" style={{ marginTop: '20px' }}>
            <h4 style={{ marginTop: 0, fontSize: '0.8rem' }}>COMMAND HISTORY</h4>
            {history.map((h, i) => (
              <div key={i} style={{ fontSize: '0.75rem', padding: '8px 0', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between' }}>
                <span>{h.command.toUpperCase()}</span>
                <span style={{ color: 'var(--muted)' }}>{new Date(h.ts).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Commands;
