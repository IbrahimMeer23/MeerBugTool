import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, setToken } from '../api.js';
import { connectWS } from '../ws.js';

const Login = () => {
  const navigate = useNavigate();
  const [booting, setBooting] = useState(true);
  const [bootLines, setBootLines] = useState([]);
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [settings, setSettings] = useState({ brandName: 'MEER HACKING HUB', brandTagline: 'Command from the shadow.' });

  const lines = [
    "INITIALIZING MEER HACKING HUB...",
    "LOADING CORE MODULES...",
    "ESTABLISHING SECURE LINK...",
    "ACCESS GRANTED"
  ];

  useEffect(() => {
    api.getSettings().then(setSettings).catch(() => {});
    
    let currentLine = 0;
    const timer = setInterval(() => {
      if (currentLine < lines.length) {
        setBootLines(prev => [...prev, lines[currentLine]]);
        currentLine++;
      } else {
        clearInterval(timer);
        setTimeout(() => setBooting(false), 500);
      }
    }, 400);

    return () => clearInterval(timer);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const res = await api.login(form.username, form.password);
      setToken(res.token);
      connectWS();
      navigate('/');
    } catch (err) {
      setError(err.message);
    }
  };

  if (booting) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000' }}>
        <div style={{ width: '400px', fontFamily: 'var(--mono)', color: 'var(--accent)' }}>
          {bootLines.map((line, i) => (
            <div key={i} style={{ marginBottom: '10px' }}>
              {line}
            </div>
          ))}
          <div style={{ width: '100%', height: '2px', background: 'var(--accent)', marginTop: '20px', animation: 'pulse-green 1s infinite' }}></div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div className="panel" style={{ width: '100%', maxWidth: '400px', textAlign: 'center', animation: 'glitch 0.3s ease-out' }}>
        <div style={{ marginBottom: '40px' }}>
          <div style={{ fontSize: '3rem', fontWeight: 'bold', color: 'var(--accent)', textShadow: '0 0 15px rgba(0,255,136,0.5)', lineHeight: '1' }}>MEER</div>
          <div style={{ fontSize: '0.9rem', color: 'var(--muted)', letterSpacing: '0.2em', marginTop: '5px' }}>HACKING HUB</div>
        </div>
        <p style={{ color: 'var(--muted)', fontSize: '0.8rem', marginBottom: '40px' }}>{settings.brandTagline}</p>
        
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <input 
            type="text" 
            placeholder="OPERATOR ID" 
            required
            value={form.username}
            onChange={e => setForm({ ...form, username: e.target.value })}
          />
          <input 
            type="password" 
            placeholder="ACCESS KEY" 
            required
            value={form.password}
            onChange={e => setForm({ ...form, password: e.target.value })}
          />
          {error && <div style={{ color: 'var(--err)', fontSize: '0.8rem' }}>{error.toUpperCase()}</div>}
          <button type="submit" className="btn-primary" style={{ marginTop: '10px' }}>AUTHENTICATE</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
