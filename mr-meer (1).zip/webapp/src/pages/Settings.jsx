import React, { useState, useEffect } from 'react';
import { api } from '../api.js';
import { useToast } from '../components/Toast.jsx';

const Settings = () => {
  const [branding, setBranding] = useState({ brandName: '', brandTagline: '' });
  const [pass, setPass] = useState({ old: '', new: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  useEffect(() => {
    api.getSettings().then(setBranding).catch(() => {});
  }, []);

  const handleBrandingSave = async () => {
    setLoading(true);
    try {
      await api.updateSettings(branding);
      toast.success('BRANDING UPDATED');
      // Force reload to update sidebar
      window.location.reload();
    } catch (err) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  const handlePassChange = async () => {
    if (pass.new !== pass.confirm) return toast.error('PASSWORDS DO NOT MATCH');
    setLoading(true);
    try {
      await api.changePassword(pass.old, pass.new);
      toast.success('PASSWORD CHANGED');
      setPass({ old: '', new: '', confirm: '' });
    } catch (err) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto' }}>
      <div className="panel" style={{ marginBottom: '30px' }}>
        <h3 style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: 0 }}>
          <span style={{ fontSize: '1.25rem', color: 'var(--accent)' }}>⚙</span> BRANDING
        </h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div>
            <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>BRAND NAME</label>
            <input 
              type="text" 
              value={branding.brandName} 
              onChange={e => setBranding({ ...branding, brandName: e.target.value })} 
            />
          </div>
          <div>
            <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>TAGLINE</label>
            <input 
              type="text" 
              value={branding.brandTagline} 
              onChange={e => setBranding({ ...branding, brandTagline: e.target.value })} 
            />
          </div>
          <button className="btn-primary" onClick={handleBrandingSave} disabled={loading} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            <span>💾</span> SAVE BRANDING
          </button>
        </div>
      </div>

      <div className="panel">
        <h3 style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: 0 }}>
          <span style={{ fontSize: '1.25rem', color: 'var(--warn)' }}>🛡</span> SECURITY
        </h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div>
            <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>OLD PASSWORD</label>
            <input 
              type="password" 
              value={pass.old} 
              onChange={e => setPass({ ...pass, old: e.target.value })} 
            />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
            <div>
              <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>NEW PASSWORD</label>
              <input 
                type="password" 
                value={pass.new} 
                onChange={e => setPass({ ...pass, new: e.target.value })} 
              />
            </div>
            <div>
              <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>CONFIRM PASSWORD</label>
              <input 
                type="password" 
                value={pass.confirm} 
                onChange={e => setPass({ ...pass, confirm: e.target.value })} 
              />
            </div>
          </div>
          <button className="btn-primary" onClick={handlePassChange} disabled={loading} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            <span>🔑</span> CHANGE PASSWORD
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;
