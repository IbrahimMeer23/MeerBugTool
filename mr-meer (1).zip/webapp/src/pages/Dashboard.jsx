import React, { useState, useEffect } from 'react';
import { api } from '../api';
import LogStream from '../components/LogStream.jsx';

const Dashboard = () => {
  const [stats, setStats] = useState({
    sessions: 0,
    connected: 0,
    commands: 0,
    recentLog: 'NO RECENT ACTIVITY'
  });
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const [sessions, commands, logs] = await Promise.all([
        api.sessions(),
        api.commandHistory(10),
        api.logs(1)
      ]);
      setStats({
        sessions: sessions.length,
        connected: sessions.filter(s => s.status === 'connected').length,
        commands: commands.length, // This is just last 50, but it gives a sense
        recentLog: logs[0]?.message || 'NO RECENT ACTIVITY'
      });
      setHistory(commands);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <h2 style={{ margin: 0 }}>SYSTEM OVERVIEW</h2>
        <button onClick={loadData} disabled={loading}>
          <span className={loading ? 'flicker' : ''}>⟳</span>
        </button>
      </div>

      <div className="stats-grid">
        <div className="panel stat-card">
          <span style={{ fontSize: '1.5rem', color: 'var(--accent)' }}>⛃</span>
          <div className="stat-value">{stats.sessions}</div>
          <div className="stat-label">TOTAL SESSIONS</div>
        </div>
        <div className="panel stat-card">
          <span style={{ fontSize: '1.5rem', color: 'var(--accent-2)' }}>⚡</span>
          <div className="stat-value">{stats.connected}</div>
          <div className="stat-label">ACTIVE LINKS</div>
        </div>
        <div className="panel stat-card">
          <span style={{ fontSize: '1.5rem', color: 'var(--warn)' }}>⌨</span>
          <div className="stat-value">{stats.commands}</div>
          <div className="stat-label">RECENT OPS</div>
        </div>
        <div className="panel stat-card">
          <span style={{ fontSize: '1.5rem', color: 'var(--accent)' }}>💬</span>
          <div className="stat-value" style={{ fontSize: '0.9rem', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>
            {stats.recentLog.toUpperCase()}
          </div>
          <div className="stat-label">LATEST SIGNAL</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' }}>
        <div>
          <h3>RECENT COMMANDS</h3>
          <div className="panel" style={{ minHeight: '400px' }}>
            {history.length === 0 && <div style={{ color: 'var(--muted)', textAlign: 'center', padding: '20px' }}>NO HISTORY</div>}
            {history.map((cmd, i) => (
              <div key={i} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)', fontSize: '0.9rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--accent)' }}>{cmd.command.toUpperCase()}</span>
                  <span style={{ color: 'var(--muted)', fontSize: '0.7rem' }}>{new Date(cmd.ts).toLocaleTimeString()}</span>
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--muted)', marginTop: '4px' }}>
                  TARGET: {JSON.parse(cmd.args).to || JSON.parse(cmd.args).target || 'N/A'}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3>LIVE ACTIVITY</h3>
          <LogStream limit={20} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
