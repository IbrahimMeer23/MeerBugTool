import React, { useState, useEffect } from 'react';
import { api } from '../api.js';
import LogStream from '../components/LogStream.jsx';

const Logs = () => {
  const [sessions, setSessions] = useState([]);
  const [filterSession, setFilterSession] = useState('');
  const [filterLevel, setFilterLevel] = useState(null);
  const [clearKey, setClearKey] = useState(0);

  useEffect(() => {
    api.sessions().then(setSessions);
  }, []);

  return (
    <div style={{ height: 'calc(100vh - 120px)', display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div className="panel" style={{ display: 'flex', alignItems: 'center', gap: '20px', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={() => setFilterLevel(null)} className={!filterLevel ? 'btn-primary' : ''}>ALL</button>
          <button onClick={() => setFilterLevel('info')} className={filterLevel === 'info' ? 'btn-primary' : ''}>INFO</button>
          <button onClick={() => setFilterLevel('warn')} className={filterLevel === 'warn' ? 'btn-primary' : ''}>WARN</button>
          <button onClick={() => setFilterLevel('error')} className={filterLevel === 'error' ? 'btn-primary' : ''}>ERROR</button>
        </div>
        
        <div style={{ flex: 1, minWidth: '200px' }}>
          <select value={filterSession} onChange={e => setFilterSession(e.target.value)}>
            <option value="">-- ALL SESSIONS --</option>
            {sessions.map(s => <option key={s.id} value={s.id}>{s.name || s.id} ({s.phone})</option>)}
          </select>
        </div>

        <button onClick={() => setClearKey(prev => prev + 1)} title="Clear View">
          <span>🗑</span>
        </button>
      </div>

      <div style={{ flex: 1, minHeight: 0 }}>
        <LogStream 
          key={clearKey}
          limit={1000} 
          filterLevel={filterLevel} 
          filterSession={filterSession} 
        />
      </div>
    </div>
  );
};

export default Logs;
