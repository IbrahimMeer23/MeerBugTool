import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { api } from '../api.js';
import { subscribeWS } from '../ws.js';
import SessionCard from '../components/SessionCard.jsx';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';

const Sessions = () => {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const toast = useToast();
  
  const [showNewModal, setShowNewModal] = useState(false);
  const [newPhone, setNewPhone] = useState('');
  
  const [pairModal, setPairModal] = useState({ open: false, session: null, type: 'qr', data: null });

  const fetchSessions = async () => {
    setLoading(true);
    try {
      const data = await api.sessions();
      setSessions(data);
    } catch (err) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSessions();
    
    const unsub = subscribeWS((event) => {
      if (event.type === 'status' || event.type === 'qr') {
        setSessions(prev => prev.map(s => s.id === event.data.id ? { ...s, ...event.data } : s));
        
        // Update current pair modal if open
        if (pairModal.open && pairModal.session.id === event.data.id) {
          if (event.type === 'qr' && pairModal.type === 'qr') {
            generateQrDataUrl(event.data.qr).then(url => {
              setPairModal(prev => ({ ...prev, data: url }));
            });
          }
          if (event.type === 'status' && event.data.status === 'connected') {
            setPairModal({ open: false, session: null, type: 'qr', data: null });
            toast.success('Session connected successfully');
          }
        }
      }
    });
    
    return unsub;
  }, [pairModal.open, pairModal.session?.id]);

  const handleCreate = async () => {
    try {
      await api.createSession(newPhone);
      setShowNewModal(false);
      setNewPhone('');
      fetchSessions();
      toast.success('Session created');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const handleDelete = async (session) => {
    if (!confirm(`Delete session ${session.id}?`)) return;
    try {
      await api.deleteSession(session.id);
      fetchSessions();
      toast.success('Session removed');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const handleLogout = async (session) => {
    try {
      await api.runCommand('session.logout', { id: session.id });
      fetchSessions();
      toast.success('Logged out');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const generateQrDataUrl = async (text) => {
    try {
      return await QRCode.toDataURL(text, { margin: 2, scale: 8, color: { dark: '#00ff88', light: '#00000000' } });
    } catch (err) {
      console.error(err);
      return null;
    }
  };

  const handlePair = async (session, type) => {
    setPairModal({ open: true, session, type, data: null });
    
    if (type === 'qr') {
      const res = await api.getQr(session.id);
      if (res.qr) {
        const url = await generateQrDataUrl(res.qr);
        setPairModal(prev => ({ ...prev, data: url }));
      }
    }
  };

  const handleRequestPairCode = async () => {
    if (!newPhone) return toast.error('Phone number required');
    try {
      const res = await api.pairSession(pairModal.session.id, newPhone);
      setPairModal(prev => ({ ...prev, data: res.code }));
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <h2 style={{ margin: 0 }}>ACTIVE SESSIONS</h2>
        <button className="btn-primary" onClick={() => setShowNewModal(true)} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span>➕</span> NEW SESSION
        </button>
      </div>

      {loading && <div style={{ color: 'var(--muted)', textAlign: 'center', padding: '50px' }}>SCANNING NETWORK...</div>}
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '20px' }}>
        {sessions.map(session => (
          <SessionCard 
            key={session.id} 
            session={session} 
            onDelete={handleDelete}
            onPair={handlePair}
            onLogout={handleLogout}
          />
        ))}
      </div>

      <Modal open={showNewModal} onClose={() => setShowNewModal(false)} title="INITIALIZE NEW SESSION">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <p style={{ fontSize: '0.85rem', color: 'var(--muted)' }}>
            Creating a new session object. You can link it via QR or pairing code after initialization.
          </p>
          <input 
            type="text" 
            placeholder="PHONE (OPTIONAL)" 
            value={newPhone} 
            onChange={e => setNewPhone(e.target.value)} 
          />
          <button className="btn-primary" onClick={handleCreate}>INITIALIZE</button>
        </div>
      </Modal>

      <Modal 
        open={pairModal.open} 
        onClose={() => setPairModal({ open: false, session: null, type: 'qr', data: null })} 
        title={pairModal.type === 'qr' ? 'SCAN QR CODE' : 'PAIRING CODE'}
      >
        <div style={{ textAlign: 'center', padding: '20px' }}>
          {pairModal.type === 'qr' ? (
            pairModal.data ? (
              <img src={pairModal.data} alt="QR" style={{ maxWidth: '300px', border: '10px solid white', borderRadius: '4px' }} />
            ) : (
              <div style={{ height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)' }}>
                GENERATING SIGNAL...
              </div>
            )
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {pairModal.data ? (
                <div style={{ fontSize: '3rem', letterSpacing: '0.2em', color: 'var(--accent)', fontWeight: 'bold' }}>
                  {pairModal.data}
                </div>
              ) : (
                <>
                  <input 
                    type="text" 
                    placeholder="PHONE (E.G. 923001234567)" 
                    value={newPhone} 
                    onChange={e => setNewPhone(e.target.value)} 
                  />
                  <button className="btn-primary" onClick={handleRequestPairCode}>GET CODE</button>
                </>
              )}
              <p style={{ fontSize: '0.75rem', color: 'var(--muted)' }}>
                ENTER THIS CODE ON YOUR PHONE'S "LINKED DEVICES" SCREEN.
              </p>
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};

export default Sessions;
