import React, { useState, useEffect } from 'react';
import { api } from '../api.js';
import { useToast } from '../components/Toast.jsx';

const Groups = () => {
  const [sessions, setSessions] = useState([]);
  const [selectedSession, setSelectedSession] = useState('');
  const [groups, setGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [loading, setLoading] = useState(false);
  const [numbers, setNumbers] = useState('');
  const [input, setInput] = useState('');
  const toast = useToast();

  useEffect(() => {
    api.sessions().then(s => setSessions(s.filter(x => x.status === 'connected')));
  }, []);

  const fetchGroups = async () => {
    if (!selectedSession) return toast.error('SELECT A SESSION');
    setLoading(true);
    try {
      const res = await api.runCommand('group.list', { id: selectedSession });
      setGroups(res.result);
      toast.success('GROUPS LOADED');
    } catch (err) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  const handleAction = async (action) => {
    if (!selectedSession || !selectedGroup) return toast.error('SESSION AND GROUP REQUIRED');
    const numbersArray = numbers.split(/[\n,]/).map(n => n.trim()).filter(n => n);
    if (numbersArray.length === 0 && !['group.leave', 'group.subject', 'group.desc'].includes(action)) {
      return toast.error('NUMBERS REQUIRED');
    }

    setLoading(true);
    try {
      const args = { id: selectedSession, group: selectedGroup.id };
      if (numbersArray.length > 0) args.numbers = numbersArray;
      if (action === 'group.subject') args.subject = input;
      if (action === 'group.desc') args.desc = input;

      await api.runCommand(action, args);
      toast.success('OPERATION SUCCESS');
      setNumbers('');
      setInput('');
      fetchGroups();
    } catch (err) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  return (
    <div>
      <div className="panel" style={{ marginBottom: '30px', display: 'flex', alignItems: 'center', gap: '20px' }}>
        <div style={{ flex: 1 }}>
          <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>SELECT ACTIVE SESSION</label>
          <select value={selectedSession} onChange={e => setSelectedSession(e.target.value)}>
            <option value="">-- SELECT SESSION --</option>
            {sessions.map(s => <option key={s.id} value={s.id}>{s.name || s.id} ({s.phone})</option>)}
          </select>
        </div>
        <button className="btn-primary" onClick={fetchGroups} disabled={loading} style={{ marginTop: '20px' }}>
          FETCH GROUPS
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' }}>
        <div>
          <h3>GROUP DIRECTORY</h3>
          <div className="panel" style={{ height: 'calc(100vh - 300px)', overflowY: 'auto' }}>
            {groups.length === 0 && <div style={{ color: 'var(--muted)', textAlign: 'center', padding: '50px' }}>NO GROUPS FOUND</div>}
            {groups.map(group => (
              <div 
                key={group.id} 
                onClick={() => setSelectedGroup(group)}
                className={`panel`}
                style={{ 
                  padding: '12px', 
                  marginBottom: '10px', 
                  cursor: 'pointer',
                  border: selectedGroup?.id === group.id ? '1px solid var(--accent)' : '1px solid var(--border)',
                  background: selectedGroup?.id === group.id ? 'rgba(0, 255, 136, 0.05)' : 'var(--panel)'
                }}
              >
                <div style={{ fontWeight: 'bold' }}>{group.subject.toUpperCase()}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--muted)', marginTop: '4px' }}>
                  {group.size} MEMBERS • OWNER: {group.owner?.split('@')[0] || 'N/A'}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3>BULK OPERATIONS</h3>
          {selectedGroup ? (
            <div className="panel" style={{ animation: 'glitch 0.2s' }}>
              <h4 style={{ color: 'var(--accent)', marginTop: 0 }}>TARGET: {selectedGroup.subject.toUpperCase()}</h4>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>TARGET NUMBERS (ONE PER LINE)</label>
                <textarea 
                  placeholder="923001234567" 
                  value={numbers} 
                  onChange={e => setNumbers(e.target.value)}
                  rows={6}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ fontSize: '0.7rem', color: 'var(--muted)', display: 'block', marginBottom: '5px' }}>INPUT (SUBJECT / DESC)</label>
                <input 
                  type="text" 
                  value={input} 
                  onChange={e => setInput(e.target.value)} 
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <button onClick={() => handleAction('group.add')} disabled={loading}>
                  <span style={{ marginRight: '8px' }}>➕👤</span> ADD
                </button>
                <button onClick={() => handleAction('group.remove')} disabled={loading}>
                  <span style={{ marginRight: '8px' }}>➖👤</span> REMOVE
                </button>
                <button onClick={() => handleAction('group.promote')} disabled={loading}>
                  <span style={{ marginRight: '8px' }}>🛡</span> PROMOTE
                </button>
                <button onClick={() => handleAction('group.demote')} disabled={loading}>
                  <span style={{ marginRight: '8px' }}>🔓</span> DEMOTE
                </button>
                <button onClick={() => handleAction('group.subject')} disabled={loading}>
                  <span style={{ marginRight: '8px' }}>🔠</span> SET SUBJECT
                </button>
                <button onClick={() => handleAction('group.desc')} disabled={loading}>
                  <span style={{ marginRight: '8px' }}>📄</span> SET DESC
                </button>
                <button onClick={() => handleAction('group.leave')} className="btn-danger" style={{ gridColumn: 'span 2' }}>
                  <span style={{ marginRight: '8px' }}>🚪</span> LEAVE GROUP
                </button>
              </div>
            </div>
          ) : (
            <div style={{ color: 'var(--muted)', textAlign: 'center', padding: '100px' }}>SELECT A GROUP TO BEGIN OPERATIONS</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Groups;
