import React, { useState, useEffect, useRef } from 'react';
import { api } from '../api.js';
import { subscribeWS } from '../ws.js';

const LogStream = ({ limit = 200, filterLevel = null, filterSession = null }) => {
  const [logs, setLogs] = useState([]);
  const containerRef = useRef(null);
  const isAtBottom = useRef(true);

  useEffect(() => {
    // Initial load
    api.logs(limit, filterSession).then(data => {
      setLogs(data.reverse());
    });

    // WS updates
    const unsub = subscribeWS((event) => {
      if (event.type === 'log') {
        const newLog = event.data;
        if (filterLevel && newLog.level !== filterLevel) return;
        if (filterSession && newLog.id !== filterSession) return;
        
        setLogs(prev => {
          const next = [...prev, newLog];
          if (next.length > limit) return next.slice(-limit);
          return next;
        });
      }
    });

    return unsub;
  }, [limit, filterLevel, filterSession]);

  useEffect(() => {
    if (isAtBottom.current && containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [logs]);

  const handleScroll = (e) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    isAtBottom.current = Math.abs(scrollHeight - scrollTop - clientHeight) < 50;
  };

  const formatTime = (ts) => new Date(ts).toLocaleTimeString('en-GB', { hour12: false });

  return (
    <div 
      ref={containerRef}
      onScroll={handleScroll}
      className="panel" 
      style={{ 
        height: '400px', 
        overflowY: 'auto', 
        fontFamily: 'var(--mono)', 
        fontSize: '0.8rem',
        background: '#050505'
      }}
    >
      {logs.length === 0 && <div style={{ color: 'var(--muted)', padding: '20px' }}>WAITING FOR LOGS...</div>}
      {logs.map((log, i) => (
        <div key={i} className="log-line">
          <span className="log-ts">[{formatTime(log.ts)}]</span>
          <span className="log-id">[{log.session_id || log.id}]</span>
          <span className={`log-level log-${log.level}`}>{log.level}</span>
          <span className="log-msg">{log.message}</span>
        </div>
      ))}
    </div>
  );
};

export default LogStream;
