import React, { useState, useEffect } from 'react';
import { subscribeWS } from '../ws.js';

const Topbar = ({ title }) => {
  const [isWsOpen, setIsWsOpen] = useState(false);

  useEffect(() => {
    const unsub = subscribeWS((event) => {
      if (event.type === 'hello') {
        setIsWsOpen(true);
      }
    });
    
    // We can't easily track raw WebSocket state from here without direct ref,
    // but the connectWS logic will retry and the hello event will trigger.
    // For simplicity, let's assume if we are receiving events, it's open.
    // A better way would be exposing state from ws.js.
    
    return unsub;
  }, []);

  return (
    <header className="topbar">
      <div style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>{title}</div>
      
      <div className={`status-indicator ${isWsOpen ? 'status-connected' : 'status-disconnected'}`}>
        <div className="status-dot"></div>
        <span>{isWsOpen ? 'LINK ACTIVE' : 'LINK LOST'}</span>
      </div>
    </header>
  );
};

export default Topbar;
