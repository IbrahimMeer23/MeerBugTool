import React, { createContext, useContext, useState, useCallback } from 'react';

const ToastContext = createContext();

export const useToast = () => useContext(ToastContext);

export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const addToast = useCallback((msg, type = 'success') => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, msg, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  const success = (msg) => addToast(msg, 'success');
  const error = (msg) => addToast(msg, 'error');

  return (
    <ToastContext.Provider value={{ success, error }}>
      {children}
      <div style={{ position: 'fixed', bottom: '20px', right: '20px', display: 'flex', flexDirection: 'column', gap: '10px', zIndex: 10000 }}>
        {toasts.map(toast => (
          <div 
            key={toast.id} 
            className="panel"
            style={{ 
              padding: '12px 20px', 
              minWidth: '250px',
              borderLeft: `4px solid ${toast.type === 'success' ? 'var(--accent)' : 'var(--err)'}`,
              animation: 'glitch 0.2s ease-out'
            }}
          >
            {toast.msg}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};
