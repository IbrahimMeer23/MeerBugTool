import React from 'react';

const SessionCard = ({ session, onDelete, onPair, onLogout }) => {
  const statusClass = session.status === 'connected' ? 'status-connected' : 
                      session.status === 'connecting' ? 'status-connecting' : 'status-disconnected';

  return (
    <div className="panel" style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
        <div>
          <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>#{session.id}</div>
          <div style={{ fontWeight: 'bold', fontSize: '1.1rem', marginTop: '4px' }}>
            {session.name || 'UNNAMED'}
          </div>
          <div style={{ fontSize: '0.9rem', color: 'var(--muted)' }}>{session.phone || 'NO PHONE'}</div>
        </div>
        <div className={`status-indicator ${statusClass}`}>
          <div className="status-dot"></div>
          <span>{session.status.toUpperCase()}</span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
        {session.status !== 'connected' && (
          <>
            <button onClick={() => onPair(session, 'qr')} title="QR Pair">
              <span>⚃</span>
            </button>
            <button onClick={() => onPair(session, 'code')} title="Code Pair">
              <span>📱</span>
            </button>
          </>
        )}
        {session.status === 'connected' && (
          <button onClick={() => onLogout(session)} style={{ gridColumn: 'span 2' }}>
            <span style={{ marginRight: '8px' }}>⏻</span> LOGOUT
          </button>
        )}
        <button onClick={() => onDelete(session)} className="btn-danger" style={{ gridColumn: session.status === 'connected' ? 'span 2' : 'span 2' }}>
          <span style={{ marginRight: '8px' }}>🗑</span> DELETE
        </button>
      </div>
    </div>
  );
};

export default SessionCard;
