import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { clearToken, api } from '../api';
import { disconnectWS } from '../ws';

const Sidebar = () => {
  const navigate = useNavigate();
  const [settings, setSettings] = useState({ brandName: 'MEER HACKING HUB', brandTagline: 'Command from the shadow.' });

  useEffect(() => {
    api.getSettings().then(setSettings).catch(() => {});
  }, []);

  const handleLogout = () => {
    clearToken();
    disconnectWS();
    navigate('/login');
  };

  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: 'var(--accent)', textShadow: '0 0 10px rgba(0,255,136,0.3)', lineHeight: '1' }}>MEER</div>
        <div style={{ fontSize: '0.6rem', color: '#6b7280', letterSpacing: '0.15em', marginTop: '4px' }}>HACKING HUB</div>
        <div className="logo-tagline" style={{ marginTop: '8px' }}>{settings.brandTagline}</div>
      </div>

      <nav className="sidebar-nav">
        <NavLink to="/" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <span style={{ marginRight: '12px' }}>⊞</span>
          DASHBOARD
        </NavLink>
        <NavLink to="/sessions" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <span style={{ marginRight: '12px' }}>⛃</span>
          SESSIONS
        </NavLink>
        <NavLink to="/commands" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <span style={{ marginRight: '12px' }}>⌨</span>
          COMMANDS
        </NavLink>
        <NavLink to="/groups" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <span style={{ marginRight: '12px' }}>👥</span>
          GROUPS
        </NavLink>
        <NavLink to="/logs" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <span style={{ marginRight: '12px' }}>📄</span>
          LOGS
        </NavLink>
        <NavLink to="/settings" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <span style={{ marginRight: '12px' }}>⚙</span>
          SETTINGS
        </NavLink>
      </nav>

      <div className="sidebar-footer">
        <button onClick={handleLogout} style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
          <span>⏻</span>
          LOGOUT
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
