import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { config } from './config.js';
import { getSetting, setSetting } from './db.js';

// Initialize admin password on first run
const initAuth = () => {
  const existingHash = getSetting('admin_pass_hash');
  if (!existingHash) {
    const hash = bcrypt.hashSync(config.adminPass, 10);
    setSetting('admin_pass_hash', hash);
  }
};

initAuth();

export const login = (username, password) => {
  if (username !== config.adminUser) return null;
  
  const hash = getSetting('admin_pass_hash');
  if (bcrypt.compareSync(password, hash)) {
    return jwt.sign({ user: username }, config.jwtSecret, { expiresIn: '7d' });
  }
  return null;
};

export const changePassword = (oldPass, newPass) => {
  const hash = getSetting('admin_pass_hash');
  if (bcrypt.compareSync(oldPass, hash)) {
    const newHash = bcrypt.hashSync(newPass, 10);
    setSetting('admin_pass_hash', newHash);
    return true;
  }
  return false;
};

export const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    req.user = decoded.user;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};
