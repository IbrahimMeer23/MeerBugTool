import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import { config } from './config.js';
import { attachWebSocket } from './ws/socket.js';
import authRouter from './routes/auth.routes.js';
import sessionRouter from './routes/session.routes.js';
import commandRouter from './routes/command.routes.js';
import logRouter from './routes/log.routes.js';
import settingsRouter from './routes/settings.routes.js';

// Boot session manager
import './whatsapp/manager.js';

const app = express();
app.use(cors({ origin: config.corsOrigins }));
app.use(express.json({ limit: '5mb' }));

// API Routes
app.use('/api/auth', authRouter);
app.use('/api/sessions', sessionRouter);
app.use('/api/commands', commandRouter);
app.use('/api/logs', logRouter);
app.use('/api/settings', settingsRouter);

// Serve static frontend if it exists
const distPath = path.join(process.cwd(), 'webapp/dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
      res.sendFile(path.join(distPath, 'index.html'));
    }
  });
}

const server = http.createServer(app);
attachWebSocket(server);

server.listen(config.port, '0.0.0.0', () => {
  console.log(`[meer-hacking-hub] listening on :${config.port}`);
});
