import express from 'express';
import { getSetting, setSetting } from '../db.js';
import { authMiddleware } from '../auth.js';

const router = express.Router();
router.use(authMiddleware);

router.get('/', (req, res) => {
  res.json({
    brandName: getSetting('brand_name', 'Meer Hacking Hub'),
    brandTagline: getSetting('brand_tagline', 'Command from the shadow.')
  });
});

router.post('/', (req, res) => {
  const { brandName, brandTagline } = req.body;
  if (brandName) setSetting('brand_name', brandName);
  if (brandTagline) setSetting('brand_tagline', brandTagline);
  res.json({ ok: true });
});

export default router;
