import express from 'express';
import { sessionManager } from '../whatsapp/manager.js';
import { authMiddleware } from '../auth.js';

const router = express.Router();
router.use(authMiddleware);

router.get('/', (req, res) => {
  res.json(sessionManager.list());
});

router.post('/', async (req, res) => {
  const { phone } = req.body;
  const session = await sessionManager.createSession(phone);
  res.json({ id: session.id, status: session.status });
});

router.delete('/:id', async (req, res) => {
  const ok = await sessionManager.remove(req.params.id);
  res.json({ ok });
});

router.get('/:id/qr', (req, res) => {
  const session = sessionManager.get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Not found' });
  res.json({
    qr: session.qr,
    status: session.status,
    pairingCode: session.pairingCode
  });
});

router.post('/:id/pair', async (req, res) => {
  const { phone } = req.body;
  const session = sessionManager.get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Not found' });
  try {
    const code = await session.requestPairingCode(phone);
    res.json({ code });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
