import express from 'express';
import { runCommand, listCommands } from '../whatsapp/commands.js';
import { authMiddleware } from '../auth.js';

const router = express.Router();
router.use(authMiddleware);

router.get('/list', (req, res) => {
  res.json(listCommands());
});

router.post('/run', async (req, res) => {
  const { name, args } = req.body;
  try {
    const result = await runCommand(name, args);
    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
