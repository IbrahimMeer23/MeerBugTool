import express from 'express';
import { db } from '../db.js';
import { authMiddleware } from '../auth.js';

const router = express.Router();
router.use(authMiddleware);

router.get('/', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 200, 1000);
  const sessionId = req.query.session;
  
  let query = 'SELECT * FROM logs ';
  const params = [];
  
  if (sessionId) {
    query += 'WHERE session_id = ? ';
    params.push(sessionId);
  }
  
  query += 'ORDER BY ts DESC LIMIT ?';
  params.push(limit);
  
  const logs = db.prepare(query).all(...params);
  res.json(logs);
});

router.get('/commands', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 200);
  const commands = db.prepare('SELECT * FROM commands ORDER BY ts DESC LIMIT ?').all(limit);
  res.json(commands);
});

export default router;
