import express from 'express';
import { login, changePassword, authMiddleware } from '../auth.js';
import { config } from '../config.js';

const router = express.Router();

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const token = login(username, password);
  if (token) {
    res.json({ token, user: username });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

router.post('/change-password', authMiddleware, (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (changePassword(oldPassword, newPassword)) {
    res.json({ ok: true });
  } else {
    res.status(400).json({ error: 'Invalid old password' });
  }
});

router.get('/me', authMiddleware, (req, res) => {
  res.json({ user: req.user, role: 'admin' });
});

export default router;
