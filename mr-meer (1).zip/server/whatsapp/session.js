import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
} from '@whiskeysockets/baileys';
import pino from 'pino';
import { EventEmitter } from 'events';
import fs from 'fs';
import path from 'path';
import { config } from '../config.js';
import { log, db } from '../db.js';

export class WASession extends EventEmitter {
  constructor(id) {
    super();
    this.id = id;
    this.authDir = path.join(config.authDir, id);
    if (!fs.existsSync(this.authDir)) {
      fs.mkdirSync(this.authDir, { recursive: true });
    }
    this.status = 'disconnected';
    this.qr = null;
    this.pairingCode = null;
    this.reconnectAttempts = 0;
    this.sock = null;
  }

  async start() {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
      const { version } = await fetchLatestBaileysVersion();
      
      this.sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        auth: state,
        browser: Browsers.ubuntu('Chrome'),
        generateHighQualityLinkPreview: false,
        syncFullHistory: false,
      });

      this.sock.ev.on('creds.update', saveCreds);

      this.sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;
        
        if (qr) {
          this.qr = qr;
          this.emit('qr', { id: this.id, qr });
          this.emitLog('info', 'QR code generated');
        }

        if (connection === 'close') {
          const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
          this.setStatus('disconnected');
          this.emitLog('warn', `Connection closed: ${lastDisconnect?.error?.message || 'unknown'}`);
          
          if (shouldReconnect) {
            this.reconnectAttempts++;
            const delay = Math.min(3000 * this.reconnectAttempts, 30000);
            this.emitLog('info', `Reconnecting in ${delay/1000}s...`);
            setTimeout(() => this.start(), delay);
          }
        } else if (connection === 'open') {
          this.reconnectAttempts = 0;
          this.qr = null;
          this.pairingCode = null;
          this.setStatus('connected');
          this.emitLog('info', 'Connection established');
          
          const phone = this.sock.user.id.split(':')[0];
          const name = this.sock.user.name;
          db.prepare('UPDATE sessions SET phone = ?, name = ?, last_seen = ? WHERE id = ?').run(
            phone, name, Date.now(), this.id
          );
        } else if (connection === 'connecting') {
          this.setStatus('connecting');
        }
      });

      this.sock.ev.on('messages.upsert', ({ messages }) => {
        this.emit('message', { id: this.id, messages });
      });

    } catch (err) {
      this.emitLog('error', `Failed to start session: ${err.message}`);
    }
  }

  async requestPairingCode(phone) {
    if (!this.sock) throw new Error('Socket not initialized');
    const digits = phone.replace(/\D/g, '');
    const code = await this.sock.requestPairingCode(digits);
    this.pairingCode = code;
    this.emitLog('info', `Pairing code requested for ${digits}`);
    return code;
  }

  async logout() {
    if (this.sock) {
      await this.sock.logout();
      this.setStatus('disconnected');
      this.emitLog('info', 'Logged out');
    }
  }

  async deleteSession() {
    await this.logout();
    if (fs.existsSync(this.authDir)) {
      fs.rmSync(this.authDir, { recursive: true, force: true });
    }
    db.prepare('DELETE FROM sessions WHERE id = ?').run(this.id);
    this.emitLog('info', 'Session deleted');
  }

  async sendMessage(jid, text) {
    if (this.status !== 'connected') throw new Error('Session not connected');
    return await this.sock.sendMessage(jid, { text });
  }

  async sendBulk(jids, text, delayMs = 1500) {
    const results = [];
    for (const jid of jids) {
      try {
        await this.sendMessage(jid, text);
        results.push({ jid, ok: true });
        await new Promise(r => setTimeout(r, delayMs));
      } catch (err) {
        results.push({ jid, ok: false, error: err.message });
      }
    }
    return results;
  }

  // Group operations
  async groupAdd(groupJid, numbers) {
    const jids = numbers.map(n => n.includes('@') ? n : `${n.replace(/\D/g, '')}@s.whatsapp.net`);
    return await this.sock.groupParticipantsUpdate(groupJid, jids, 'add');
  }

  async groupRemove(groupJid, numbers) {
    const jids = numbers.map(n => n.includes('@') ? n : `${n.replace(/\D/g, '')}@s.whatsapp.net`);
    return await this.sock.groupParticipantsUpdate(groupJid, jids, 'remove');
  }

  async groupPromote(groupJid, numbers) {
    const jids = numbers.map(n => n.includes('@') ? n : `${n.replace(/\D/g, '')}@s.whatsapp.net`);
    return await this.sock.groupParticipantsUpdate(groupJid, jids, 'promote');
  }

  async groupDemote(groupJid, numbers) {
    const jids = numbers.map(n => n.includes('@') ? n : `${n.replace(/\D/g, '')}@s.whatsapp.net`);
    return await this.sock.groupParticipantsUpdate(groupJid, jids, 'demote');
  }

  async groupCreate(name, numbers) {
    const jids = numbers.map(n => n.includes('@') ? n : `${n.replace(/\D/g, '')}@s.whatsapp.net`);
    return await this.sock.groupCreate(name, jids);
  }

  async groupLeave(groupJid) {
    return await this.sock.groupLeave(groupJid);
  }

  async setGroupSubject(groupJid, subject) {
    return await this.sock.groupUpdateSubject(groupJid, subject);
  }

  async setGroupDescription(groupJid, desc) {
    return await this.sock.groupUpdateDescription(groupJid, desc);
  }

  async fetchGroups() {
    const groups = await this.sock.groupFetchAllParticipating();
    return Object.values(groups).map(g => ({
      id: g.id,
      subject: g.subject,
      size: g.participants.length,
      owner: g.owner
    }));
  }

  async blockUser(jid) {
    return await this.sock.updateBlockStatus(jid, 'block');
  }

  async unblockUser(jid) {
    return await this.sock.updateBlockStatus(jid, 'unblock');
  }

  async profilePic(jid) {
    try {
      return await this.sock.profilePictureUrl(jid, 'image');
    } catch {
      return null;
    }
  }

  async checkNumber(number) {
    const digits = number.replace(/\D/g, '');
    const [result] = await this.sock.onWhatsApp(digits);
    return result;
  }

  emitLog(level, message) {
    log(this.id, level, message);
    this.emit('log', { id: this.id, level, message, ts: Date.now() });
  }

  setStatus(status) {
    this.status = status;
    db.prepare('UPDATE sessions SET status = ? WHERE id = ?').run(status, this.id);
    this.emit('status', { id: this.id, status });
  }
}
