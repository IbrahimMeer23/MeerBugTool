import { EventEmitter } from 'events';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { WASession } from './session.js';
import { db } from '../db.js';
import { config } from '../config.js';

class SessionManager extends EventEmitter {
  constructor() {
    super();
    this.sessions = new Map();
    this.init();
  }

  async init() {
    // Load existing sessions from DB
    const rows = db.prepare('SELECT id FROM sessions').all();
    for (const row of rows) {
      const authDir = path.join(config.authDir, row.id);
      if (fs.existsSync(authDir)) {
        const session = this.createSessionObject(row.id);
        session.start();
      }
    }
  }

  createSessionObject(id) {
    const session = new WASession(id);
    
    // Relay events
    session.on('log', (data) => this.emit('log', data));
    session.on('status', (data) => this.emit('status', data));
    session.on('qr', (data) => this.emit('qr', data));
    session.on('message', (data) => this.emit('message', data));

    this.sessions.set(id, session);
    return session;
  }

  async createSession(phone = null) {
    const id = crypto.randomBytes(6).toString('hex');
    const now = Date.now();
    
    db.prepare('INSERT INTO sessions (id, phone, status, created_at) VALUES (?, ?, ?, ?)').run(
      id, phone, 'disconnected', now
    );

    const session = this.createSessionObject(id);
    await session.start();
    return session;
  }

  get(id) {
    return this.sessions.get(id);
  }

  list() {
    return db.prepare('SELECT * FROM sessions').all();
  }

  async remove(id) {
    const session = this.sessions.get(id);
    if (session) {
      await session.deleteSession();
      this.sessions.delete(id);
      return true;
    }
    return false;
  }
}

export const sessionManager = new SessionManager();
