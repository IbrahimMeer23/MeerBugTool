import { sessionManager } from './manager.js';
import { recordCommand } from '../db.js';

const toJid = (input) => {
  if (input.includes('@')) return input;
  return `${input.replace(/\D/g, '')}@s.whatsapp.net`;
};

const commands = {
  'session.pair': async ({ id, phone }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return { code: await session.requestPairingCode(phone) };
  },
  'session.logout': async ({ id }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    await session.logout();
    return { ok: true };
  },
  'msg.send': async ({ id, to, text }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    const result = await session.sendMessage(toJid(to), text);
    return { ok: true, result };
  },
  'msg.bulk': async ({ id, targets, text, delayMs }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    const jids = targets.map(t => toJid(t));
    const results = await session.sendBulk(jids, text, delayMs);
    return { results };
  },
  'group.create': async ({ id, name, members }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.groupCreate(name, members);
  },
  'group.add': async ({ id, group, numbers }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.groupAdd(toJid(group), numbers);
  },
  'group.remove': async ({ id, group, numbers }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.groupRemove(toJid(group), numbers);
  },
  'group.promote': async ({ id, group, numbers }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.groupPromote(toJid(group), numbers);
  },
  'group.demote': async ({ id, group, numbers }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.groupDemote(toJid(group), numbers);
  },
  'group.leave': async ({ id, group }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.groupLeave(toJid(group));
  },
  'group.subject': async ({ id, group, subject }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.setGroupSubject(toJid(group), subject);
  },
  'group.desc': async ({ id, group, desc }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.setGroupDescription(toJid(group), desc);
  },
  'group.list': async ({ id }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.fetchGroups();
  },
  'user.check': async ({ id, number }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.checkNumber(number);
  },
  'user.block': async ({ id, target }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.blockUser(toJid(target));
  },
  'user.unblock': async ({ id, target }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return await session.unblockUser(toJid(target));
  },
  'user.pfp': async ({ id, target }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    return { url: await session.profilePic(toJid(target)) };
  },
  'attack.flood': async ({ id, target, count, text, delayMs }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    const jid = toJid(target);
    const limit = Math.min(count, 5000);
    let sent = 0;
    let failed = 0;
    for (let i = 0; i < limit; i++) {
      try {
        await session.sendMessage(jid, text);
        sent++;
        if (delayMs) await new Promise(r => setTimeout(r, delayMs));
      } catch {
        failed++;
        if (failed > 20) break;
      }
    }
    return { sent, failed };
  },
  'attack.random': async ({ id, target, count, texts, minMs, maxMs }) => {
    const session = sessionManager.get(id);
    if (!session) throw new Error('Session not found');
    const jid = toJid(target);
    const limit = Math.min(count, 5000);
    let sent = 0;
    let failed = 0;
    for (let i = 0; i < limit; i++) {
      try {
        const text = texts[Math.floor(Math.random() * texts.length)];
        await session.sendMessage(jid, text);
        sent++;
        const delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
        await new Promise(r => setTimeout(r, delay));
      } catch {
        failed++;
        if (failed > 20) break;
      }
    }
    return { sent, failed };
  }
};

export const runCommand = async (name, args) => {
  const handler = commands[name];
  if (!handler) throw new Error(`Unknown command: ${name}`);
  
  const result = await handler(args);
  recordCommand(args.id, name, args, result);
  return result;
};

export const listCommands = () => Object.keys(commands);
