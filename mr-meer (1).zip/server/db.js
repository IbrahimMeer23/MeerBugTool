import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { config } from './config.js';

const dbDir = path.dirname(config.dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(config.dbPath);

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    phone TEXT,
    name TEXT,
    status TEXT DEFAULT 'disconnected',
    created_at INTEGER,
    last_seen INTEGER
  );

  CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT,
    level TEXT,
    message TEXT,
    ts INTEGER
  );

  CREATE TABLE IF NOT EXISTS commands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT,
    command TEXT,
    args TEXT,
    result TEXT,
    ts INTEGER
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

export const log = (sessionId, level, message) => {
  const ts = Date.now();
  db.prepare('INSERT INTO logs (session_id, level, message, ts) VALUES (?, ?, ?, ?)').run(sessionId, level, message, ts);
};

export const recordCommand = (sessionId, command, args, result) => {
  const ts = Date.now();
  db.prepare('INSERT INTO commands (session_id, command, args, result, ts) VALUES (?, ?, ?, ?, ?)').run(
    sessionId,
    command,
    JSON.stringify(args),
    JSON.stringify(result),
    ts
  );
};

export const getSetting = (key, fallback) => {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : fallback;
};

export const setSetting = (key, value) => {
  db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(key, value);
};

export { db };
