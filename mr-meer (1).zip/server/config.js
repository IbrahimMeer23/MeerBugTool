import dotenv from 'dotenv';
dotenv.config();

export const config = {
  port: process.env.NODE_ENV === 'production' ? 3000 : 3001,
  jwtSecret: process.env.JWT_SECRET || 'secret_key_default_change_it',
  adminUser: process.env.ADMIN_USER || 'admin',
  adminPass: process.env.ADMIN_PASS || 'admin123',
  dbPath: process.env.DB_PATH || './data/mrmeer.db',
  authDir: process.env.AUTH_DIR || './data/auth',
  corsOrigins: (process.env.CORS_ORIGINS || 'http://localhost:5173').split(','),
};
