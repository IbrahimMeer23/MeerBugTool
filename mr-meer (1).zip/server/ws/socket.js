import { WebSocketServer } from 'ws';
import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { sessionManager } from '../whatsapp/manager.js';

export const attachWebSocket = (httpServer) => {
  const wss = new WebSocketServer({ noServer: true });

  httpServer.on('upgrade', (request, socket, head) => {
    const url = new URL(request.url, `http://${request.headers.host}`);
    const token = url.searchParams.get('token');

    if (!token) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }

    try {
      jwt.verify(token, config.jwtSecret);
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } catch (err) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
    }
  });

  wss.on('connection', (ws) => {
    ws.send(JSON.stringify({ type: 'hello', data: { time: Date.now() } }));

    const onLog = (data) => ws.send(JSON.stringify({ type: 'log', data }));
    const onStatus = (data) => ws.send(JSON.stringify({ type: 'status', data }));
    const onQr = (data) => ws.send(JSON.stringify({ type: 'qr', data }));
    const onMessage = (data) => ws.send(JSON.stringify({ type: 'message', data }));

    sessionManager.on('log', onLog);
    sessionManager.on('status', onStatus);
    sessionManager.on('qr', onQr);
    sessionManager.on('message', onMessage);

    ws.on('close', () => {
      sessionManager.off('log', onLog);
      sessionManager.off('status', onStatus);
      sessionManager.off('qr', onQr);
      sessionManager.off('message', onMessage);
    });
  });

  return wss;
};
